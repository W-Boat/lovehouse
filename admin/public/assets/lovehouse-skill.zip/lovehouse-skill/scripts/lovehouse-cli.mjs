import {existsSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {loadEnvFile} from 'node:process';

const here=dirname(fileURLToPath(import.meta.url));
const envFile=process.env.LOVEHOUSE_ENV_FILE||resolve(here,'../.ENV');
if(existsSync(envFile))loadEnvFile(envFile);
const [command,...args]=process.argv.slice(2);
const base=process.env.LOVEHOUSE_CONTENT_SERVER;
const usage='Usage: lovehouse-cli.mjs pull OUTPUT | upload FILE | check INPUT | push INPUT REVISION | publish INPUT OUTPUT | serve SNAPSHOT | history SNAPSHOT';
const requireArgs=(count)=>{if(args.length!==count)throw new Error(usage)};
try{
 if(!command||['help','-h','--help'].includes(command)){console.log(usage);process.exit(0)}
 const repo=process.env.LOVEHOUSE_REPO||process.cwd();
 const cli=resolve(repo,'tools/cloud-content.mjs');
 if(!existsSync(cli))throw new Error('Set LOVEHOUSE_REPO to a Lovehouse checkout in .ENV.');
 if(['pull','upload','push'].includes(command)&&!base)throw new Error('Set LOVEHOUSE_CONTENT_SERVER in .ENV.');
 if(['pull','upload','push'].includes(command)&&!process.env.LOVEHOUSE_ADMIN_TOKEN)throw new Error('Set LOVEHOUSE_ADMIN_TOKEN in .ENV.');
 let forwarded;
 switch(command){
 case 'pull':requireArgs(1);forwarded=[base,resolve(args[0])];break;
 case 'upload':requireArgs(1);forwarded=[resolve(args[0]),base];break;
 case 'push':requireArgs(2);forwarded=[resolve(args[0]),base,args[1]];break;
 case 'publish':requireArgs(2);forwarded=args.map(value=>resolve(value));break;
 case 'check':
 case 'history':
 case 'serve':requireArgs(1);forwarded=[resolve(args[0])];break;
 default:throw new Error(usage);
 }
 const result=spawnSync(process.execPath,[cli,command,...forwarded],{cwd:resolve(repo),stdio:'inherit'});
 if(result.error)throw result.error;
 process.exitCode=result.status??1;
}catch(error){console.error(error.message);process.exitCode=1}
