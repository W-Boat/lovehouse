---
name: lovehouse-skill
description: Develop and operate W-Boat/lovehouse, including cloud content publishing, Phaser gameplay, the Vue admin, signed client packages, and GitHub Actions handoffs.
---

先读 [Agent.MD](Agent.MD) 和 [HANDOFF.md](HANDOFF.md)，再根据任务选择参考。开始工作前确认当前仓库、分支和工作树，交接时写入实际变更与未完成项。

- 开发入口和可直接运行的命令见 [开发指南](references/development.md)。
- 内容发布、素材和版本回滚见 [CLI](references/cli.md)。
- 模块归属和请求流见 [架构与模块](references/architecture.md)。
- 构建、部署、安装包及回滚见 [Actions 与发布](references/actions.md)。

仓库自带 CLI 是执行与校验的入口。用 `scripts/lovehouse-cli.mjs` 连接已克隆的仓库。配置从本机 `.ENV` 或进程环境读取，复制 [.ENV.example](.ENV.example) 后填写。线上变更按用户授权范围执行。
